:mod:`semaphore` -- Semaphore classes
==================================================

.. autoclass:: eventlet.semaphore.Semaphore
	:members:

.. autoclass:: eventlet.semaphore.BoundedSemaphore
	:members:
	
.. autoclass:: eventlet.semaphore.CappedSemaphore
	:members: