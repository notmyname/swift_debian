__threading = __import__('threading')
from eventlet import patcher
from eventlet.green import thread
from eventlet.green import time

__patched__ = ['_start_new_thread', '_allocate_lock', '_get_ident', '_sleep',
               'local', 'stack_size', 'Lock', 'currentThread',
               'current_thread']

patcher.inject('threading',
    globals(),
    ('thread', thread),
    ('time', time))

del patcher


singleton_dummy = __threading._DummyThread()

def current_thread():
    try:
        return __threading._active[__threading._get_ident()]
    except KeyError:
        return singleton_dummy

currentThread = current_thread
